A Pen created at CodePen.io. You can find this one at http://codepen.io/Huskie/pen/wHKor.

 A CSS3 side panel with menu and associated content which transitions in from the right hand side of the page. The whole body of the page moves left to create this effect.